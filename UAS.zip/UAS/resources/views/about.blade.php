@include('tampilan.main')

    <p>About</p>
@include('tampilan.footer')