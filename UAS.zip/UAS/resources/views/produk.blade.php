@include('tampilan.main')

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produk</title>
    <link rel="stylesheet" href="produk.css" />
</head>
<body>
    <div class="pproduk">
        <p>Ini produk</p>
    </div>



    @include('tampilan.footer')
</body>
</html>