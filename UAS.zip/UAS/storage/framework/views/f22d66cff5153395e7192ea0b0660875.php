<?php echo $__env->make('tampilan.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="index.css" />
</head>

<body>
    <div class="atas">
        <div class="moto">
            <p>
                Lorem ipsum
                dolor sit amet,
                consectetur
                adipiscing elit
            </p>
        </div>

        <div class="buttonatas">
            <a href="produk">
                <button class="btnatas">Produk Kami</button>
            </a>
        </div>
    </div>

    <div class="pmesin">
        <div class="mesin">
            <p><b>Mesin-Mesin Yang Digunakan</b></p>
        </div>

        <div class="fotomesin">
            <p>Foto-Foto Mesin</p>
        </div>
    </div>

    <div class="pproduk">
        <div class="produk">
            <p><b>Contoh Produk Yang Diproduksi</b></p>
        </div>

        <div class="fotoproduk">
            <p>Foto-Foto Produk</p>
        </div>

        <a href="produk">
            <button class="btnatas">Lihat Semua Produk</button>
        </a>
    </div>

    <div class="paboutus">
        <div class="aboutuscard">
            <div class="aboutuscontent">
                <p><b><h2>Tri Daya Langgeng</h2></b></p>
                <p>2015 To Today</p>
                <p>PT ini bergerak di bidang percetakan sparepart motor dan mobil, sparepart pesanan dari konsumen PT lain, untuk motor HONDA KAWASAKI untuk mobil tergantung pesanan</p>
                
                <div class="btnabout">
                    <a href="about">
                        <button class="btnatas">Tentang Kami</button>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('tampilan.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH D:\Laravel\UAS\resources\views/index.blade.php ENDPATH**/ ?>