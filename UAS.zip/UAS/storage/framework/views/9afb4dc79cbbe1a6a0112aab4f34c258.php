<?php echo $__env->make('tampilan.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produk</title>
    <link rel="stylesheet" href="produk.css" />
</head>
<body>
    <div class="pproduk">
        <p>Ini produk</p>
    </div>



    <?php echo $__env->make('tampilan.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH D:\Laravel\UAS\resources\views/produk.blade.php ENDPATH**/ ?>