<?php echo $__env->make('tampilan.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <p>About</p>
<?php echo $__env->make('tampilan.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\UAS\resources\views/about.blade.php ENDPATH**/ ?>