lakukan php artisan storage:link saat ingin melakukan crud. gunakan hanya 1x saja
lalu lakukan php artisan migrate untuk database.

kalo ada yang gak paham tanya aja.

