@include('tampilan.main')

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produk</title>
    <link rel="stylesheet" href="{{ asset('css/produk.css') }}" />
</head>
<body>
    <div class="pproduk">
        <h1>Daftar Produk</h1>

        @foreach($produk as $produk)
            <div class="produk-item">
                <a href="{{ route('detail.produk', ['id' => $produk->id]) }}">
                    <img src="{{ asset('storage/'.$produk->gambar) }}" alt="Product Image">
                </a>
                <p>Part NO : {{ $produk->part_no }}</p>
                <p>NAMA PRODUK : {{ $produk->part_name }}</p>
                <p>Dekspripsi : {{ $produk->deskripsi }}</p>
            </div>
        @endforeach
    </div>

    @include('tampilan.footer')
</body>
</html>
