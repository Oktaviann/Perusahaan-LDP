@include('tampilan.main')

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="{{ asset('css/index.css') }}">
</head>

<body>
    <div class="atas">
        <div class="moto">
            <p>
                Pergudangan Sunrise Bizpark Blok E No.18 Kuta Jaya, 
                Pasar Kemis, Kab. Tangerang

            </p>
        </div>

        <div class="buttonatas">
            <a href="produk">
                <button class="btnatas">Produk Kami</button>
            </a>
        </div>
    </div>

    <div class="pmesin">
        <div class="mesin">
            <p><b>Mesin-Mesin Yang Digunakan</b></p>
        </div>

        <div class="fotomesin">
            <div class="row">
                <div class="col-4">
                    <img src="{{ asset('foto/WhatsApp Image 2023-11-22 at 22.01.53 (1).jpeg') }}" alt="Foto Mesin 1" class="img-fluid">
                </div>
                <div class="col-4">
                    <img src="{{ asset('foto/WhatsApp Image 2023-11-22 at 22.01.51.jpeg') }}" alt="Foto Mesin 1">
                </div>
                <div class="col-4">
                <img src="{{ asset('foto/WhatsApp Image 2023-11-22 at 22.01.47.jpeg') }}" alt="Foto Mesin 1">
                </div>
                <div class="col-4">
                <img src="{{ asset('foto/WhatsApp Image 2023-11-22 at 22.01.53 (2).jpeg') }}" alt="Foto Mesin 1">
                </div>
                <div class="col-4">
                <img src="{{ asset('foto/WhatsApp Image 2023-11-22 at 22.01.53.jpeg') }}" alt="Foto Mesin 1">
                </div>
                <div class="col-4">
                    <img src="{{ asset('foto/WhatsApp Image 2023-11-22 at 22.01.53 (1).jpeg') }}" alt="Foto Mesin 1" class="img-fluid">
                </div>
            </div>
        </div>
    </div>

    <div class="pproduk">
        <div class="produk">
            <p><b>Contoh Produk Yang Diproduksi</b></p>
        </div>

        <div class="fotoproduk">
            <p>Foto-Foto Produk</p>
        </div>

        <a href="produk">
            <button class="btnatas">Lihat Semua Produk</button>
        </a>
    </div>

    <div class="paboutus">
        <div class="aboutuscard">
            <div class="aboutuscontent">
                <p><b><h2>Tri Daya Langgeng</h2></b></p>
                <p>2015 To Today</p>
                <p>PT ini bergerak di bidang percetakan sparepart motor dan mobil, sparepart pesanan dari konsumen PT lain, untuk motor HONDA KAWASAKI untuk mobil tergantung pesanan</p>
                
                <div class="btnabout">
                    <a href="about">
                        <button class="btnatas">Tentang Kami</button>
                    </a>
                </div>
            </div>
        </div>
    </div>

    @include('tampilan.footer')

</body>

</html>
