@include('tampilan.main')

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Data</title>
</head>
<body>
    <h1>Edit Data</h1>

    @if(session('success'))
        <div style="color: green;">
            {{ session('success') }}
        </div>
    @endif

    @if(session('error'))
        <div style="color: red;">
            {{ session('error') }}
        </div>
    @endif

    <form action="{{ url('/update-data/'.$data->id) }}" method="post" enctype="multipart/form-data">
        @csrf
        <label for="gambar">Gambar:</label>
        <input type="file" name="gambar" accept="image/*">
        <br>
        <label for="part_no">Part No:</label>
        <input type="text" name="part_no" value="{{ $data->part_no }}" required>
        <br>
        <label for="part_name">Part Name:</label>
        <input type="text" name="part_name" value="{{ $data->part_name }}" required>
        <br>
        <label for="deskripsi">Deskripsi:</label>
        <textarea name="deskripsi" required>{{ $data->deskripsi }}</textarea>
        <br>
        <br>
        <button type="submit">Update Data</button>
    </form>

    <a href="{{ url('/crud') }}">Kembali ke Data</a>
    @include('tampilan.footer')
</body>
</html>