@include('tampilan.main')
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="{{ asset('css/login.css') }}">
</head>
<body>
    <div class="login">
        <div class="cardlogin">
            <div class="cardkonten">
                <p class="welcome"><b>Welcome Back</b></p>

                @if(session('error'))
                    <div class="alert alert-danger">
                        {{ session('error') }}
                    </div>
                @endif

                <form action="{{ url('/login') }}" method="POST">
                    @csrf
                    <input class="kotak" type="text" name="txtUname" placeholder="Username" required><br><br><br>
                    <input class="kotak" type="password" name="txtPass" placeholder="Password" required><br>
                    <input class="btnsubmit" type="submit" value="Login">
                </form>

            </div>
        </div>
    </div>
@include('tampilan.footer')
</body>
</html>