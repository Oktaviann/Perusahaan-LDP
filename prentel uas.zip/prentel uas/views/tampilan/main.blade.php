<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="{{ asset('css/main.css') }}">
</head>

<body>
<div class="atas">
    <nav class="navbar navbar-expand-lg">
        <a class="navbar-brand" href="/"><b>TDL</b></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item">
                    <a class="nav-link" aria-current="page" href="/"><b>Beranda</b></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ url('/produk') }}"><b>Produk</b></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ url('/about') }}"><b>Tentang Kami</b></a>
                </li>
            </ul>

            <ul class="navbar-nav">
                @if(session('username'))
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <b>{{ session('username') }}</b>
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li class="ddlogout"><a href="{{ url('/logout') }}">Logout</a></li>
                        </ul>
                    </li>
                @else
                    <li class="nav-item">
                        <a class="nav-link" href="login"><b>Login</b></a>
                    </li>
                @endif
            </ul>
        </div>
    </nav>
</div>

</body>

</html>